# Minislate

This is Minislate, a minimalist, opinionated WYSIWYG editor. It aims at getting things
right and avoiding common pitfalls of web editors.


## Minimalist & opinionated

One of the most challenging tasks with web editors is to keep it as simple as possible
while having it work on major platforms. Here are some strong principles followed by
Minislate:

 - What you need, when you need it, based on context Extensible components (buttons and
 - menus) Vanilla JavaScript. No framework, keep yours!

## Download and install

First, [download Minislate](http://olivier-m.github.io/minislate) and unzip it.

Add the following code in the `head` element of your page:

```html
<link rel="stylesheet" href="css/minislate-full.min.css" />
```

At the bottom of the page, before the `</body>` tag, add this code:

```html
<script src="js/minislate.js"></script>
<script>
window.addEventListener('DOMContentLoaded', function() {
  var editor = new Minislate('#editable', {
  });
});
</script>
```
